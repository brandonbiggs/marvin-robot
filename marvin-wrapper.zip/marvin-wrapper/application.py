#!/usr/bin/env python3
# This is a blank file ready for your program

from modules.robot import *

robot = Robot()